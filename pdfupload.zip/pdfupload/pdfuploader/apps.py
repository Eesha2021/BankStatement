from django.apps import AppConfig


class PdfuploaderConfig(AppConfig):
    name = 'pdfuploader'
